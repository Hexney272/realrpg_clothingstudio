Config = {}

Config.Debug = true
Config.Locale = 'hu'

-- auto / esx / qb / qbox
Config.Framework = 'auto'
Config.Inventory = 'ox_inventory'

Config.OpenCommand = 'clothingstudio'
Config.UseCommand = true

Config.Studio = {
    title = 'RealRPG Clothing Studio',
    accent = '#d7ff00',
    maxUploadMB = 4,
    allowedExtensions = { png = true, jpg = true, jpeg = true, webp = true },
}

-- Designer station access. job = nil means public.
Config.Stations = {
    {
        label = 'RealRPG Clothing Studio',
        coords = vec3(72.30, -1399.10, 29.38),
        radius = 2.0,
        job = nil,
        grade = 0
    },
    {
        label = 'Burger Shot Designer',
        coords = vec3(-1198.20, -894.40, 13.90),
        radius = 2.0,
        job = 'burgershot',
        grade = 2
    }
}

Config.DrawMarker = true
Config.Marker = {
    type = 2,
    scale = vec3(0.25, 0.25, 0.25),
    color = { r = 215, g = 255, b = 0, a = 180 }
}

-- Money/item printing settings
Config.Printing = {
    enabled = true,
    price = 2500,
    account = 'money', -- money/bank depending framework
    items = {
        tops = 'printed_tshirt',
        undershirt = 'printed_undershirt',
        pants = 'printed_pants',
        shoes = 'printed_shoes'
    }
}

-- Upload bridge placeholder. In this MVP, designs are stored as JSON in DB.
-- For production, use a real upload endpoint/CDN or Discord webhook bridge.
Config.UploadBridge = {
    enabled = false,
    discordWebhook = '',
}

-- AI placeholder. Add your API bridge server-side later.
Config.AI = {
    enabled = false,
    provider = 'gemini',
    apiKey = ''
}

-- How close the player must be to open station with E.
Config.InteractDistance = 2.0
