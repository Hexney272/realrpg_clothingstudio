local function notify(src, msg, typ)
    TriggerClientEvent('realrpg_clothingstudio:client:notify', src, msg, typ or 'info')
end

local function canUseStation(src, stationIndex)
    local station = Config.Stations[stationIndex]
    if not station then return false end
    if not station.job then return true end

    local job, grade = ServerFW.GetJob(src)
    return job == station.job and grade >= (station.grade or 0)
end

local function makeDesignId(src)
    return ('rr_%s_%s_%04d'):format(os.time(), src, math.random(1000, 9999))
end

RegisterNetEvent('realrpg_clothingstudio:server:requestOpen', function(stationIndex)
    local src = source
    if not canUseStation(src, stationIndex) then
        notify(src, 'Nincs jogosultságod ehhez a designer station-höz.', 'error')
        return
    end

    local identifier = ServerFW.GetIdentifier(src)
    local designs = DB.GetMyDesigns(identifier)

    TriggerClientEvent('realrpg_clothingstudio:client:openStudio', src, {
        title = Config.Studio.title,
        accent = Config.Studio.accent,
        templates = Templates.List,
        myDesigns = designs,
        aiEnabled = Config.AI.enabled,
        maxUploadMB = Config.Studio.maxUploadMB
    })
end)

RegisterNetEvent('realrpg_clothingstudio:server:saveDesign', function(payload)
    local src = source
    if type(payload) ~= 'table' then return end

    local identifier = ServerFW.GetIdentifier(src)
    local designId = makeDesignId(src)
    local label = tostring(payload.label or 'Untitled Design'):sub(1, 80)
    local gender = tostring(payload.gender or 'male')
    local category = tostring(payload.category or 'tops')
    local templateId = tostring(payload.templateId or '')
    local template = Templates.Get(gender, category, templateId)

    if not template then
        notify(src, 'Érvénytelen ruha sablon.', 'error')
        return
    end

    local designJson = json.encode(payload.design or {})
    local preview = payload.preview

    DB.SaveDesign({
        design_id = designId,
        owner_identifier = identifier,
        owner_name = ServerFW.GetName(src),
        label = label,
        gender = gender,
        category = category,
        template_id = templateId,
        design_json = designJson,
        preview_data = preview,
        image_url = payload.imageUrl
    })

    notify(src, 'Design elmentve.', 'success')
    TriggerClientEvent('realrpg_clothingstudio:client:designSaved', src, {
        design_id = designId,
        label = label,
        gender = gender,
        category = category,
        template_id = templateId,
        preview_data = preview,
        image_url = payload.imageUrl
    })
end)

RegisterNetEvent('realrpg_clothingstudio:server:printDesign', function(payload)
    local src = source
    if not Config.Printing.enabled then return end
    if type(payload) ~= 'table' or not payload.designId then return end

    local design = DB.GetDesign(payload.designId)
    if not design then
        notify(src, 'A design nem található.', 'error')
        return
    end

    local paid = ServerFW.RemoveMoney(src, Config.Printing.price, Config.Printing.account)
    if not paid then
        notify(src, ('Nincs elég pénzed. Ár: $%s'):format(Config.Printing.price), 'error')
        return
    end

    local template = Templates.Get(design.gender, design.category, design.template_id)
    if not template then
        notify(src, 'A design sablonja nem található.', 'error')
        return
    end

    local metadata = {
        label = design.label,
        description = ('Egyedi RealRPG ruha: %s'):format(design.label),
        designId = design.design_id,
        gender = design.gender,
        category = design.category,
        templateId = design.template_id,
        component = template.component,
        drawable = template.drawable,
        texture = template.texture,
        preview = design.preview_data,
        image = design.preview_data,
        creator = design.owner_name,
        createdAt = design.created_at
    }

    local ok, err = Inv.AddPrintedItem(src, design.category, metadata)
    if not ok then
        notify(src, err or 'Nem sikerült létrehozni az itemet.', 'error')
        return
    end

    notify(src, 'A ruhát kinyomtattad és bekerült az inventorydba.', 'success')
end)

RegisterNetEvent('realrpg_clothingstudio:server:setEquipped', function(metadata)
    local src = source
    if type(metadata) ~= 'table' or not metadata.designId or not metadata.category then return end
    local identifier = ServerFW.GetIdentifier(src)
    DB.SetEquipped(identifier, metadata.category, metadata.designId, metadata)
    TriggerClientEvent('realrpg_clothingstudio:client:syncWearable', -1, src, metadata)
end)

AddEventHandler('playerJoining', function()
    -- Client requests reload on spawn.
end)

RegisterNetEvent('realrpg_clothingstudio:server:requestEquipped', function()
    local src = source
    local identifier = ServerFW.GetIdentifier(src)
    local rows = DB.GetEquipped(identifier)
    local equipped = {}
    for _, row in ipairs(rows) do
        equipped[row.category] = json.decode(row.metadata or '{}')
    end
    TriggerClientEvent('realrpg_clothingstudio:client:loadEquipped', src, equipped)
end)
