local equipped = {}
local remoteEquipped = {}

local function applyClothing(metadata)
    if type(metadata) ~= 'table' then return end
    local ped = PlayerPedId()
    local component = tonumber(metadata.component)
    local drawable = tonumber(metadata.drawable)
    local texture = tonumber(metadata.texture or 0)
    if not component or not drawable then return end

    SetPedComponentVariation(ped, component, drawable, texture, 2)
end

RegisterNetEvent('realrpg_clothingstudio:client:wearItem', function(metadata)
    if type(metadata) ~= 'table' then return end
    applyClothing(metadata)
    equipped[metadata.category or 'tops'] = metadata
    TriggerServerEvent('realrpg_clothingstudio:server:setEquipped', metadata)
end)

RegisterNetEvent('realrpg_clothingstudio:client:loadEquipped', function(data)
    equipped = data or {}
    for _, metadata in pairs(equipped) do
        applyClothing(metadata)
    end
end)

RegisterNetEvent('realrpg_clothingstudio:client:syncWearable', function(serverId, metadata)
    -- This MVP syncs the wearable metadata. Real runtime texture projection can be added here.
    remoteEquipped[serverId] = remoteEquipped[serverId] or {}
    remoteEquipped[serverId][metadata.category or 'tops'] = metadata
end)
