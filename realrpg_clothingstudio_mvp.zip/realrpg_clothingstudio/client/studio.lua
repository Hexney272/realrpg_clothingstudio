local studioOpen = false

RegisterNetEvent('realrpg_clothingstudio:client:openStudio', function(data)
    studioOpen = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'open', data = data })
end)

RegisterNUICallback('close', function(_, cb)
    studioOpen = false
    SetNuiFocus(false, false)
    cb({ ok = true })
end)

RegisterNUICallback('saveDesign', function(data, cb)
    TriggerServerEvent('realrpg_clothingstudio:server:saveDesign', data)
    cb({ ok = true })
end)

RegisterNUICallback('printDesign', function(data, cb)
    TriggerServerEvent('realrpg_clothingstudio:server:printDesign', data)
    cb({ ok = true })
end)

RegisterNUICallback('previewClothing', function(data, cb)
    TriggerEvent('realrpg_clothingstudio:client:previewClothing', data)
    cb({ ok = true })
end)

RegisterNetEvent('realrpg_clothingstudio:client:designSaved', function(design)
    SendNUIMessage({ action = 'designSaved', design = design })
end)
