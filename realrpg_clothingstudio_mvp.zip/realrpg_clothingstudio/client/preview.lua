local previewOriginal = {}

RegisterNetEvent('realrpg_clothingstudio:client:previewClothing', function(data)
    if type(data) ~= 'table' then return end
    local template = data.template
    if type(template) ~= 'table' then return end
    local ped = PlayerPedId()
    local component = tonumber(template.component)
    if not component then return end

    if not previewOriginal[component] then
        previewOriginal[component] = {
            drawable = GetPedDrawableVariation(ped, component),
            texture = GetPedTextureVariation(ped, component)
        }
    end

    SetPedComponentVariation(ped, component, tonumber(template.drawable) or 0, tonumber(template.texture) or 0, 2)
end)
