Templates = {}

-- GTA freemode clothing component ids:
-- 11 = tops, 8 = undershirt, 4 = pants, 6 = shoes
Templates.List = {
    male = {
        tops = {
            { id = 'm_top_basic_001', label = 'Basic T-Shirt', component = 11, drawable = 15, texture = 0, preview = 'assets/tshirt.png', uv = 'assets/uv_tshirt.png' },
            { id = 'm_top_staff_001', label = 'Staff Shirt', component = 11, drawable = 16, texture = 0, preview = 'assets/tshirt.png', uv = 'assets/uv_tshirt.png' }
        },
        undershirt = {
            { id = 'm_under_basic_001', label = 'Basic Undershirt', component = 8, drawable = 15, texture = 0, preview = 'assets/tshirt.png', uv = 'assets/uv_tshirt.png' }
        },
        pants = {
            { id = 'm_pants_basic_001', label = 'Basic Pants', component = 4, drawable = 1, texture = 0, preview = 'assets/pants.png', uv = 'assets/uv_pants.png' }
        },
        shoes = {
            { id = 'm_shoes_basic_001', label = 'Basic Shoes', component = 6, drawable = 1, texture = 0, preview = 'assets/shoes.png', uv = 'assets/uv_shoes.png' }
        }
    },
    female = {
        tops = {
            { id = 'f_top_basic_001', label = 'Basic T-Shirt', component = 11, drawable = 15, texture = 0, preview = 'assets/tshirt.png', uv = 'assets/uv_tshirt.png' }
        },
        undershirt = {},
        pants = {},
        shoes = {}
    }
}

function Templates.Get(gender, category, id)
    local list = Templates.List[gender] and Templates.List[gender][category]
    if not list then return nil end
    for _, t in ipairs(list) do
        if t.id == id then return t end
    end
    return nil
end
