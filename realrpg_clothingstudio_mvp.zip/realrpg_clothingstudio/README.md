# RealRPG Clothing Studio MVP

Ingame clothing creator FiveM resource ESX/QBCore/Qbox detection + ox_inventory support.

## Fontos
Ez egy stabil MVP alap. A NUI editor, rétegek, mentés, nyomtatott item, item használat, component drawable felvétel és persistence alap benne van.
A tényleges runtime texture projection / DUI garment wrap következő fejlesztési lépés, mert ehhez saját blank `.ydd/.ytd` template slotok és material/runtime texture mapping szükséges.

## Telepítés
1. Másold a `realrpg_clothingstudio` mappát a resources mappába.
2. Futtasd az `sql/install.sql` fájlt az adatbázisban.
3. Add hozzá a server.cfg-hez:
   ```cfg
   ensure oxmysql
   ensure ox_inventory
   ensure realrpg_clothingstudio
   ```
4. ox_inventory `data/items.lua` példa:
   ```lua
   ['printed_tshirt'] = {
       label = 'Printed T-Shirt',
       weight = 250,
       stack = false,
       close = true,
       description = 'Egyedi nyomtatott póló'
   },
   ['printed_undershirt'] = {
       label = 'Printed Undershirt',
       weight = 250,
       stack = false,
       close = true
   },
   ['printed_pants'] = {
       label = 'Printed Pants',
       weight = 350,
       stack = false,
       close = true
   },
   ['printed_shoes'] = {
       label = 'Printed Shoes',
       weight = 500,
       stack = false,
       close = true
   },
   ```
5. Parancs: `/clothingstudio`, vagy menj a `Config.Stations` koordinátához és nyomj E-t.

## Következő fejlesztési lépések
- Valódi DUI/runtime texture rávetítés streamelt blank garment slotokra.
- Discord webhook/CDN upload bridge nagy képekhez.
- Gemini AI server-side bridge.
- My Designs panel teljes betöltés/megnyitás.
- Designer station ox_target támogatás.
- Automatikus garment template discovery stream mappából.
