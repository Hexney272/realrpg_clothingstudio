fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'RealRPG / ChatGPT'
description 'RealRPG Clothing Studio - Ingame clothing designer MVP for ESX/QBCore/Qbox + ox_inventory'
version '0.1.0'

ui_page 'web/index.html'

files {
    'web/index.html',
    'web/style.css',
    'web/app.js',
    'web/assets/*.png',
    'web/assets/*.svg',
    'stream/**/*'
}

shared_scripts {
    '@ox_lib/init.lua', -- optional, script has fallback; remove if you do not use ox_lib
    'config.lua',
    'shared/templates.lua',
    'shared/framework.lua'
}

client_scripts {
    'client/main.lua',
    'client/studio.lua',
    'client/wearables.lua',
    'client/preview.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/database.lua',
    'server/framework.lua',
    'server/inventory.lua',
    'server/main.lua'
}

dependencies {
    'oxmysql'
}
